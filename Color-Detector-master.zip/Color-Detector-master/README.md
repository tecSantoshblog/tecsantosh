# Color-Detector
Arduino color detection using TSC3200
